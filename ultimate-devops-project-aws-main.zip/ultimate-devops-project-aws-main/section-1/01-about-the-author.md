# About the Author

Hi Everyone, My name is Abhishek Veeramalla, I am a Principal software engineer and an educator with 400k community on YouTube.

I am also an opensource enthusiast who believes in sharing knowledge. I have my footprints in popular opensource projects like Argo CD, Argo CD Operator, Argo Rollouts Manager, GitOps Operator, F5 Ingress Controller, Nginx Ingress Controller by Nginx and others. 

Apart from working with Red Hat as a GitOps product lead, I also hold below positions in OpenSource communities
- Maintainer of Argo CD Operator
- Creator of Argo Rollouts Manager
- Maintainer of RedHat Developer (GitOps operator)
- Member of Argo Project
- Member of Argo SIG Security

If you want to learn complete devops and cloud for Free, you can checkout my YouTube channel.
```
https://www.youtube.com/abhishekveeramalla
```


